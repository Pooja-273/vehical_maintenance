import 'package:flutter/foundation.dart';

class SearchModel{


}