package model;

public class    TimeModel {

    String Date;
    int id;

}
