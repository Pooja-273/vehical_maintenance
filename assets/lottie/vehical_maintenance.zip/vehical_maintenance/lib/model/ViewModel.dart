import 'package:flutter/foundation.dart';

class ViewModel{
  final String image;
  final String name;

  ViewModel(this.image,this.name);
}