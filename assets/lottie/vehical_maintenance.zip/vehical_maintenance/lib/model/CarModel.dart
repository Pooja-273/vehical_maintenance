import 'package:flutter/foundation.dart';

class CarModel{
   int id;
  final String title;
  final String categories;
  final String image;

  CarModel(this.id, this.title, this.categories, this.image);




}