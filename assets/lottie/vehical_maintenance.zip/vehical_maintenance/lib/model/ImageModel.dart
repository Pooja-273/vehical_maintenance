import 'package:flutter/foundation.dart';

class ImageModel{
  final String image;
  
  ImageModel(this.image);
}