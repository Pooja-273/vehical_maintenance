package com.example.vehical_maintenance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
