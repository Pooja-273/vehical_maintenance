package models;

import java.io.Serializable;

public class Employee implements Serializable {
    public int id;
    public String name;
    public String mobile;
    public String drivingLicense;
    public String photo;
    public boolean fromServicko;


}
