package models;

public class Address {
}
