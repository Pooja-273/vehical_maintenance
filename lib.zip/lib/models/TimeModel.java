package models;

public class    TimeModel {

    String Date;
    int id;

}
