

class ServiceCenterModel{
  final String image;
  final String title;
  final String star;
  final String rating;
  final String location;
  final String area;
  final String pickup;
  final String managedby;
  final String price;
  final String subcategories;



  ServiceCenterModel(this.image,this.title, this.star, this.rating, this.location, this.area, this.pickup, this.managedby,this.price,this.subcategories);


}

