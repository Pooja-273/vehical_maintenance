class Post {
  final String title;


  Post(this.title);
}