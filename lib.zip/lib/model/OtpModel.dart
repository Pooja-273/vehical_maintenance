

class OtpModel{
  final String heading;
  final String title;
  final String number;
  final String text;


  OtpModel(this.heading,this.title,this.number,this.text);
}