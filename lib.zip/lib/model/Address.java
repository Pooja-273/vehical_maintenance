package model;

public class Address {
}
