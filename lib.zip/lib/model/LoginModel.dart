

class LoginModel{

  final String name;

  LoginModel(this.name);

}

