package model;

import java.io.Serializable;

public class Code implements Serializable {
    public int id;
    public String type;
    public int discount;




}