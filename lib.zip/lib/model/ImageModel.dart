

class ImageModel{
  final String image;
  
  ImageModel(this.image);
}