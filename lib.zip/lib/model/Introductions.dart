import 'package:flutter/foundation.dart';

class Introduction {
  final String phone;

  Introduction({this.phone});
  factory Introduction.fromJson(Map<String,dynamic>json){
    return Introduction(
      phone: json['phone'],
    );
  }
}
