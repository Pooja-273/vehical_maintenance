package model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Vehicle {

    public String brand;
    public String name;

    public String regNumber;

    public long brandId;

    public long vehicleId;

    public int type;

    public long userVehicleId;




}
