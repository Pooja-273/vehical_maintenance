

class PersonalDetailsModel{
  final String heading;
  final String title;
  final String name;
  final String emailid;
  final String vehiclename;
  final String vehicleregisternum;
  final String text;

  PersonalDetailsModel(this.heading,this.title,this.name,this.emailid,this.vehiclename,this.vehicleregisternum,this.text);
}