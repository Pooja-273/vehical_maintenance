class Api {
  static const base_url = "https://api.servicko.com/";
  static const register_mobile_url =
      "https://api.servicko.com/user/register/mobile";
}
